return (
      <div className="row">
            <h2>{title}</h2>
            {/*<h4>{itemsToRender}</h4> */}
                  {                  movies ? movies.map(movie=>{
                   <img src={`${base_url}${isLargeRow? movie.poster_path: movie.backdrop_path}`}
                  alt={movie.title} />
                  }): "Not Yet Working"}     
            
      </div>
)
}





<div className="row__posters">
                        {                  movies ? movies.map(movie=>{
                        return <img
                        
                        className={`row__poster ${isLargeRow && "row__posterLarge"}`} 
                        
                        src={`${base_url}${isLargeRow? movie.poster_path: movie.backdrop_path}`}

                        alt={movie.title|| movie.name} />
                        }): "Not Yet Working"
                        } 
                        </div>









return (
      <div className="row">
            <h2>{title}</h2>
            
                 <div className="row__posters">
                  {                  movies ? movies.map(movie=>
                  ((isLargeRow && movie.poster_path)||(!isLargeRow && movie.backdrop_path))&&(
                  <img                    className={`row__poster ${isLargeRow && "row__posterLarge"}`} 
                  
                  src={`${base_url}${isLargeRow? movie.poster_path: movie.backdrop_path}`}

                  alt={movie.title|| movie.name} />
                  )): "Not Yet Working"
                  } 
                  </div>  